// pages/api/generate-avatar.ts
import type { NextApiRequest, NextApiResponse } from "next";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { text } = req.body;

  if (!text) {
    return res.status(400).json({ error: "Text is required" });
  }

  const HEYGEN_API_KEY = process.env.NEXT_PUBLIC_HEYGEN_API_KEY;

  if (!HEYGEN_API_KEY) {
    return res.status(500).json({ error: "Heygen API key is not configured" });
  }

  try {
    // Step 1: Create a text-to-speech task
    const ttsResponse = await fetch(
      "https://api.heygen.com/v1/text_to_speech",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": HEYGEN_API_KEY,
        },
        body: JSON.stringify({
          text: text,
          voice_id: "en-US-1", // Use an appropriate voice ID from Heygen
          output_format: "mp3",
        }),
      }
    );

    if (!ttsResponse.ok) {
      const errorData = await ttsResponse.json();
      throw new Error(`TTS API error: ${JSON.stringify(errorData)}`);
    }

    const ttsData = await ttsResponse.json();
    const audioUrl = ttsData.data.audio_url;

    // Step 2: Create a talking avatar video
    const avatarResponse = await fetch(
      "https://api.heygen.com/v1/talking_avatar",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": HEYGEN_API_KEY,
        },
        body: JSON.stringify({
          avatar_id: "avatar_01", // Use a default avatar ID or pass from frontend
          audio_url: audioUrl,
          background: {
            type: "color",
            value: "#FFFFFF",
          },
          ratio: "16:9",
        }),
      }
    );

    if (!avatarResponse.ok) {
      const errorData = await avatarResponse.json();
      throw new Error(`Avatar API error: ${JSON.stringify(errorData)}`);
    }

    const avatarData = await avatarResponse.json();

    return res.status(200).json({
      avatar_id: avatarData.data.video_id,
      avatar_url: avatarData.data.video_url,
      status: avatarData.data.status,
    });
  } catch (error) {
    console.error("Heygen API error:", error);
    return res.status(500).json({
      error:
        error instanceof Error ? error.message : "Failed to generate avatar",
    });
  }
}
