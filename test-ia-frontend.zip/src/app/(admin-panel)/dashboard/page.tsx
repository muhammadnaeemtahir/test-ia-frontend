export default function Dashboard() {
  return (
    <>
      <h1>Hello, Dashboard!</h1>
    </>
  )
}
